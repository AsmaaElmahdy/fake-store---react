import React from 'react'
import './styles.css';

export default function Cart() {
  return (
    <div className='page404'>
        <h1>
            Cart Here !!!!
        </h1>
    </div>
  )
}
