import React from 'react'
import "./styles.css";

export default function Footer() {
  return (
    <div className='footer'>
        <h3>
            Copyrights Frontend G3 at 2022 &copy;
        </h3>
    </div>
  )
}
