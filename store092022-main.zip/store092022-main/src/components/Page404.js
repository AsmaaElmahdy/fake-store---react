import React from 'react'
import './styles.css';

export default function Page404() {
  return (
    <div className='page404'>
        <h2>
            Page Not Found
        </h2>
    </div>
  )
}
